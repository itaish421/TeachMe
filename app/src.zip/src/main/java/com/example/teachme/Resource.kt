package com.example.teachme

class Resource<T>(
    var loaded: Boolean = false,
    var data: T?,
)
