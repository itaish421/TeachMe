package com.example.teachme

data object Constants {

    val SUBJECTS = listOf<String>(
        "History",
        "Math",
        "Physics",
        "Guitar",
        "Personal Trainer",
        "Literature",
        "Computer Science"
    )


}